import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AgentTypeSelector } from './AgentTypeSelector';
import { PersonalityConfigurator } from './PersonalityConfigurator';
import { SkillsSelector } from './SkillsSelector';
import { WorkflowDesigner } from './workflow/WorkflowDesigner';
import { useAgentBuilder } from '../../hooks/useAgentBuilder';
import { useAgentStore } from '../../store/agentStore';
import { ModernCard } from '../ui/ModernCard';
import { ModernButton } from '../ui/ModernButton';
import { Save, AlertCircle, User, FileText } from 'lucide-react';

export const AgentBuilder: React.FC = () => {
  const navigate = useNavigate();
  const { selectAgent } = useAgentStore();
  const { 
    config,
    updateConfig,
    saveAgent,
    isValid,
    validationErrors 
  } = useAgentBuilder();

  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    if (!isValid || isSaving) return;
    
    setIsSaving(true);
    try {
      const createdAgent = await saveAgent();
      
      if (createdAgent) {
        console.log(`🎉 Agent "${createdAgent.name}" created successfully!`);
        
        // Auto-select the newly created agent
        selectAgent({
          id: createdAgent.id,
          name: createdAgent.name,
          type: createdAgent.type,
          description: config.description || '',
          expertise: config.skills?.map(s => s.name) || [],
          isAvailable: true,
          personality: config.personality
        });
        
        // Navigate to agents page
        setTimeout(() => {
          navigate('/agents');
        }, 500);
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600">
            <Save className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-white">Configure Your Agent</h2>
        </div>
        <ModernButton
          onClick={handleSave}
          disabled={!isValid || isSaving}
          variant="primary"
          className="flex items-center gap-2"
        >
          {isSaving ? (
            <>
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Saving...</span>
            </>
          ) : (
            <>
              <Save className="w-5 h-5" />
              <span>Save Agent</span>
            </>
          )}
        </ModernButton>
      </div>

      {/* Basic Details Section */}
      <ModernCard variant="glass" className="p-6">
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <User className="w-5 h-5 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Basic Details</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="agent-name" className="block text-sm font-medium text-gray-300 mb-2">
                Agent Name *
              </label>
              <input
                id="agent-name"
                type="text"
                value={config.name || ''}
                onChange={(e) => updateConfig({ name: e.target.value })}
                placeholder="e.g., HR Assistant, Finance Advisor, Customer Support Bot"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            </div>

            <div>
              <label htmlFor="agent-description" className="block text-sm font-medium text-gray-300 mb-2">
                Description *
              </label>
              <textarea
                id="agent-description"
                value={config.description || ''}
                onChange={(e) => updateConfig({ description: e.target.value })}
                placeholder="Describe what this agent does and its primary responsibilities..."
                rows={3}
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
              />
            </div>
          </div>
        </div>
      </ModernCard>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <ModernCard variant="glass" className="p-6">
            <AgentTypeSelector
              selectedType={config.type}
              onSelect={(type) => updateConfig({ type })}
            />
          </ModernCard>
          
          <ModernCard variant="glass" className="p-6">
            <PersonalityConfigurator
              personality={config.personality}
              onChange={(personality) => updateConfig({ personality })}
            />
          </ModernCard>
          
          <ModernCard variant="glass" className="p-6">
            <SkillsSelector
              skills={config.skills}
              onChange={(skills) => updateConfig({ skills })}
            />
          </ModernCard>
        </div>

        <div className="lg:border-l lg:border-white/10 lg:pl-6">
          <ModernCard variant="glass" className="p-6">
            <WorkflowDesigner
              workflows={config.workflows}
              onChange={(workflows) => updateConfig({ workflows })}
            />
          </ModernCard>
        </div>
      </div>

      {!isValid && (
        <ModernCard variant="glass" className="p-6 border-red-500/50">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-red-400 font-semibold mb-2">Configuration Errors:</h3>
              <ul className="space-y-1">
                {validationErrors.map((error, index) => (
                  <li key={index} className="text-red-300 text-sm">• {error}</li>
                ))}
              </ul>
            </div>
          </div>
        </ModernCard>
      )}
    </div>
  );
};