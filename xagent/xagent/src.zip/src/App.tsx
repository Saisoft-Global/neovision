import { useEffect } from 'react';
import { BrowserRouter } from 'react-router-dom';
import { ConnectionStatus } from './components/common/ConnectionStatus';
import { AppRoutes } from './routes';
import { ConversationManager } from './services/conversation/ConversationManager';

export const App = () => {
  useEffect(() => {
    // Initialize conversation management system
    const conversationManager = ConversationManager.getInstance();
    conversationManager.initialize();

    // Cleanup on unmount
    return () => {
      conversationManager.shutdown();
    };
  }, []);

  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-100">
        <AppRoutes />
        <ConnectionStatus />
      </div>
    </BrowserRouter>
  );
};