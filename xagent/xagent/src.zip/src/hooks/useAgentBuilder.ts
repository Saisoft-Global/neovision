import { useState } from 'react';
import { AgentFactory } from '../services/agent/AgentFactory';
import type { AgentConfig } from '../types/agent-framework';

// Core skills that are automatically added to every agent
const CORE_SKILLS = [
  { name: 'natural_language_understanding', level: 5 },
  { name: 'task_comprehension', level: 5 },
  { name: 'reasoning', level: 4 },
  { name: 'context_retention', level: 4 }
];

const defaultConfig: AgentConfig = {
  name: '',                             // User must provide name
  description: '',                      // User must provide description
  personality: {
    friendliness: 0.7,
    formality: 0.7,
    proactiveness: 0.7,
    detail_orientation: 0.7,
  },
  skills: [...CORE_SKILLS], // Start with core skills
  knowledge_bases: [],
  llm_config: {
    provider: 'openai',
    model: 'gpt-4-turbo-preview',
    temperature: 0.7,
  },
  workflows: [], // Array of workflow IDs
};

export function useAgentBuilder() {
  const [config, setConfig] = useState<AgentConfig>(defaultConfig);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const validateConfig = (config: AgentConfig): string[] => {
    const errors: string[] = [];

    // Validate name
    if (!config.name || config.name.trim() === '' || config.name === 'New Agent') {
      errors.push('Agent name is required');
    }

    // Validate description
    if (!config.description || config.description.trim() === '' || config.description === 'AI Agent') {
      errors.push('Agent description is required');
    }

    // Personality is optional - we have defaults
    // if (!config.personality) {
    //   errors.push('Personality configuration is required');
    // }

    // Skills are now auto-added, but still validate
    if (!config.skills || config.skills.length === 0) {
      errors.push('At least one skill is required');
    }

    // LLM config is optional - we have defaults
    // if (!config.llm_config?.provider) {
    //   errors.push('LLM provider must be specified');
    // }

    // Agent type is the only required field
    if (!config.type) {
      errors.push('Agent type must be selected');
    }

    return errors;
  };

  const updateConfig = (updates: Partial<AgentConfig>) => {
    const newConfig = { ...config, ...updates };
    setConfig(newConfig);
    setValidationErrors(validateConfig(newConfig));
  };

  const saveAgent = async (): Promise<{ id: string; name: string; type: string } | null> => {
    const errors = validateConfig(config);
    if (errors.length) {
      setValidationErrors(errors);
      alert(`Validation errors:\n${errors.join('\n')}`);
      return null;
    }

    try {
      console.log('💾 Saving agent with config:', {
        type: config.type,
        skillsCount: config.skills?.length || 0,
        hasPersonality: !!config.personality,
        hasLLM: !!config.llm_config
      });

      const factory = AgentFactory.getInstance();
      const agent = await factory.createToolEnabledAgent(config, []);
      
      // Link workflows to agent if any selected
      if (config.workflows && config.workflows.length > 0) {
        const { getSupabaseClient } = await import('../config/supabase');
        const supabase = getSupabaseClient();
        
        await supabase
          .from('agent_workflows')
          .insert(
            config.workflows.map(workflowId => ({
              agent_id: agent.id,
              workflow_id: workflowId,
            }))
          );
          
        console.log(`✅ Linked ${config.workflows.length} workflows to agent`);
      }
      
      // Handle success
      console.log('✅ Agent created successfully:', agent);
      
      // Clear form for next agent
      setConfig(defaultConfig);
      
      // Return agent info for navigation
      return {
        id: agent.id,
        name: config.name || 'New Agent',
        type: config.type || 'general'
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to create agent';
      const errorDetails = error instanceof Error ? error.stack : JSON.stringify(error);
      
      console.error('❌ Error creating agent:', error);
      console.error('Error details:', errorDetails);
      
      setValidationErrors([errorMessage]);
      alert(`❌ Failed to create agent:\n\n${errorMessage}\n\nCheck console for details.`);
      return null;
    }
  };

  return {
    config,
    updateConfig,
    saveAgent,
    isValid: validationErrors.length === 0,
    validationErrors,
  };
}