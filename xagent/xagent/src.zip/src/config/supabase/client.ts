// Re-export from the main index file to maintain compatibility
export { 
  supabase, 
  getSupabaseClient, 
  isSupabaseAvailable, 
  isSupabaseConnected 
} from './index';