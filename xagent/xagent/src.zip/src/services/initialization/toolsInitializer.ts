/**
 * Tools Initialization Service
 * 
 * This service initializes all tools at application startup
 * Should be called once when the app loads
 */

import { toolRegistry } from '../tools/ToolRegistry';
import { EmailTool } from '../tools/implementations/EmailTool';
import { CRMTool } from '../tools/implementations/CRMTool';

let isInitialized = false;

/**
 * Initialize all tools
 * Safe to call multiple times (will only initialize once)
 */
export function initializeTools(): void {
  if (isInitialized) {
    console.log('⏭️  Tools already initialized, skipping...');
    return;
  }

  try {
    console.log('🔧 Initializing Tools & Skills Framework...');
    
    // Register Email Tool
    toolRegistry.registerTool(EmailTool);
    
    // Register CRM Tool  
    toolRegistry.registerTool(CRMTool);
    
    // Get statistics
    const stats = toolRegistry.getStatistics();
    console.log('✅ Tools initialized successfully:', stats);
    
    isInitialized = true;
  } catch (error) {
    console.error('❌ Failed to initialize tools:', error);
    throw error;
  }
}

/**
 * Check if tools have been initialized
 */
export function areToolsInitialized(): boolean {
  return isInitialized;
}

/**
 * Force re-initialization (useful for testing)
 */
export function reinitializeTools(): void {
  isInitialized = false;
  initializeTools();
}

