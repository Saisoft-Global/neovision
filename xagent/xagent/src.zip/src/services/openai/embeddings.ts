// OpenAI embeddings service with fallback
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

export const generateEmbeddings = async (text: string): Promise<number[]> => {
  if (!OPENAI_API_KEY) {
    console.warn('OpenAI API key not configured, generating mock embeddings');
    // Generate a mock embedding vector (1536 dimensions like OpenAI)
    return new Array(1536).fill(0).map(() => Math.random() * 2 - 1);
  }

  try {
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        input: text,
        model: 'text-embedding-ada-002'
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.data[0].embedding;
  } catch (error) {
    console.error('OpenAI embeddings failed:', error);
    // Fallback to mock embeddings
    console.warn('Falling back to mock embeddings');
    return new Array(1536).fill(0).map(() => Math.random() * 2 - 1);
  }
};

export const generateEmbeddingsBatch = async (texts: string[]): Promise<number[][]> => {
  if (!OPENAI_API_KEY) {
    console.warn('OpenAI API key not configured, generating mock embeddings for batch');
    return texts.map(() => new Array(1536).fill(0).map(() => Math.random() * 2 - 1));
  }

  try {
    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        input: texts,
        model: 'text-embedding-ada-002'
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return data.data.map((item: any) => item.embedding);
  } catch (error) {
    console.error('OpenAI batch embeddings failed:', error);
    // Fallback to mock embeddings
    console.warn('Falling back to mock embeddings for batch');
    return texts.map(() => new Array(1536).fill(0).map(() => Math.random() * 2 - 1));
  }
};

export const isOpenAIAvailable = (): boolean => {
  return !!OPENAI_API_KEY;
};