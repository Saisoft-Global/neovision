/**
 * LLM Configuration Manager
 * Centralized management of LLM providers with intelligent fallbacks
 */

import { userLLMSettingsService, UserLLMSettings } from './UserLLMSettingsService';

export interface LLMProviderConfig {
  name: string;
  apiKey: string;
  baseUrl?: string;
  isAvailable: boolean;
  priority: number; // Lower number = higher priority
  fallbackTo?: string; // Which provider to fallback to
}

export interface LLMConfigManagerOptions {
  enableFallbacks: boolean;
  defaultProvider: string;
  logLevel: 'silent' | 'info' | 'debug';
}

export class LLMConfigManager {
  private static instance: LLMConfigManager;
  private providers: Map<string, LLMProviderConfig> = new Map();
  private options: LLMConfigManagerOptions;
  private currentUserId: string | null = null;
  private userSettings: UserLLMSettings | null = null;

  private constructor(options?: Partial<LLMConfigManagerOptions>) {
    this.options = {
      enableFallbacks: true,
      defaultProvider: 'openai',
      logLevel: 'info',
      ...options
    };
    
    this.initializeProviders();
  }

  public static getInstance(options?: Partial<LLMConfigManagerOptions>): LLMConfigManager {
    if (!LLMConfigManager.instance) {
      LLMConfigManager.instance = new LLMConfigManager(options);
    }
    return LLMConfigManager.instance;
  }

  /**
   * Initialize all providers with environment variables (fallback)
   */
  private initializeProviders(): void {
    // 🚀 GROQ - Ultra-fast inference
    this.addProvider({
      name: 'groq',
      apiKey: import.meta.env.VITE_GROQ_API_KEY || '',
      baseUrl: 'https://api.groq.com/openai/v1',
      isAvailable: !!import.meta.env.VITE_GROQ_API_KEY,
      priority: 1, // Highest priority for speed
      fallbackTo: 'openai'
    });

    // 🧠 MISTRAL - Best reasoning
    this.addProvider({
      name: 'mistral',
      apiKey: import.meta.env.VITE_MISTRAL_API_KEY || '',
      baseUrl: 'https://api.mistral.ai/v1',
      isAvailable: !!import.meta.env.VITE_MISTRAL_API_KEY,
      priority: 2,
      fallbackTo: 'openai'
    });

    // ✍️ ANTHROPIC CLAUDE - Best creativity
    this.addProvider({
      name: 'anthropic',
      apiKey: import.meta.env.VITE_ANTHROPIC_API_KEY || '',
      baseUrl: 'https://api.anthropic.com/v1',
      isAvailable: !!import.meta.env.VITE_ANTHROPIC_API_KEY,
      priority: 3,
      fallbackTo: 'openai'
    });

    // 🌍 GOOGLE GEMINI - Best multilingual
    this.addProvider({
      name: 'google',
      apiKey: import.meta.env.VITE_GOOGLE_API_KEY || '',
      baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
      isAvailable: !!import.meta.env.VITE_GOOGLE_API_KEY,
      priority: 4,
      fallbackTo: 'openai'
    });

    // 💻 OPENAI - Reliable fallback
    this.addProvider({
      name: 'openai',
      apiKey: import.meta.env.VITE_OPENAI_API_KEY || '',
      baseUrl: import.meta.env.VITE_OPENAI_BASE_URL || 'https://api.openai.com/v1',
      isAvailable: !!import.meta.env.VITE_OPENAI_API_KEY,
      priority: 5, // Lowest priority (fallback)
      fallbackTo: null // No fallback - this is the ultimate fallback
    });

    // 🏠 OLLAMA - Local models (always available if running)
    this.addProvider({
      name: 'ollama',
      apiKey: '', // No API key needed
      baseUrl: 'http://localhost:11434',
      isAvailable: false, // Will be checked dynamically
      priority: 6,
      fallbackTo: 'openai'
    });

    this.log('info', `🔧 LLM Config Manager initialized with ${this.providers.size} providers`);
    this.logAvailableProviders();
  }

  /**
   * Load user-specific LLM settings
   */
  async loadUserSettings(userId: string): Promise<void> {
    try {
      this.currentUserId = userId;
      this.userSettings = await userLLMSettingsService.getUserSettings(userId);
      
      if (this.userSettings) {
        this.log('info', `👤 Loaded LLM settings for user: ${userId}`);
        
        // Update provider configurations with user's API keys
        this.updateProvidersWithUserKeys();
        
        // Update task recommendations with user's overrides
        this.updateTaskRecommendations();
        
        this.logAvailableProviders();
      } else {
        this.log('warn', `⚠️ No LLM settings found for user: ${userId}`);
      }
    } catch (error) {
      this.log('error', `❌ Error loading user settings for ${userId}: ${error}`);
    }
  }

  /**
   * Update provider configurations with user's API keys
   */
  private updateProvidersWithUserKeys(): void {
    if (!this.userSettings) return;

    // Update each provider with user's API key if available
    const keyMappings = {
      openai: this.userSettings.openaiApiKey,
      groq: this.userSettings.groqApiKey,
      mistral: this.userSettings.mistralApiKey,
      anthropic: this.userSettings.anthropicApiKey,
      google: this.userSettings.googleApiKey
    };

    for (const [providerName, apiKey] of Object.entries(keyMappings)) {
      const provider = this.providers.get(providerName);
      if (provider && apiKey) {
        provider.apiKey = apiKey;
        provider.isAvailable = true;
        this.log('debug', `🔑 Updated ${providerName} with user API key`);
      }
    }
  }

  /**
   * Update task recommendations with user's overrides
   */
  private updateTaskRecommendations(): void {
    if (!this.userSettings) return;

    // This will be used by the LLMRouter to override default recommendations
    this.log('debug', `🎯 User has ${Object.keys(this.userSettings.taskOverrides).length} task overrides`);
  }

  /**
   * Clear user settings (for logout)
   */
  clearUserSettings(): void {
    this.currentUserId = null;
    this.userSettings = null;
    
    // Reset providers to environment variable defaults
    this.initializeProviders();
    
    this.log('info', '👤 Cleared user LLM settings');
  }

  /**
   * Add a provider configuration
   */
  private addProvider(config: LLMProviderConfig): void {
    this.providers.set(config.name, config);
  }

  /**
   * Get provider configuration
   */
  public getProvider(name: string): LLMProviderConfig | undefined {
    return this.providers.get(name);
  }

  /**
   * Get all available providers
   */
  public getAvailableProviders(): LLMProviderConfig[] {
    return Array.from(this.providers.values())
      .filter(provider => provider.isAvailable)
      .sort((a, b) => a.priority - b.priority);
  }

  /**
   * Get the best available provider for a task type
   */
  public getBestProviderForTask(taskType: string): LLMProviderConfig | null {
    // If user settings are loaded, use them
    if (this.userSettings) {
      return this.getBestProviderForTaskWithUserSettings(taskType);
    }

    // Fallback to environment-based recommendations
    const recommendations = this.getTaskRecommendations();
    const recommendedProvider = recommendations[taskType];
    
    if (!recommendedProvider) {
      return this.getDefaultProvider();
    }

    // Check if recommended provider is available
    const provider = this.getProvider(recommendedProvider);
    if (provider && provider.isAvailable) {
      this.log('debug', `🎯 Using recommended provider for ${taskType}: ${provider.name}`);
      return provider;
    }

    // Fallback to next best option
    if (this.options.enableFallbacks && provider?.fallbackTo) {
      const fallbackProvider = this.getProvider(provider.fallbackTo);
      if (fallbackProvider && fallbackProvider.isAvailable) {
        this.log('info', `⚠️ Recommended provider ${recommendedProvider} not available, using fallback: ${fallbackProvider.name}`);
        return fallbackProvider;
      }
    }

    // Ultimate fallback to default
    return this.getDefaultProvider();
  }

  /**
   * Get the best available provider for a task type using user settings
   */
  private getBestProviderForTaskWithUserSettings(taskType: string): LLMProviderConfig | null {
    if (!this.userSettings) return this.getDefaultProvider();

    // Check user's task overrides first
    if (this.userSettings.taskOverrides[taskType]) {
      const override = this.userSettings.taskOverrides[taskType];
      const provider = this.getProvider(override.provider);
      
      if (provider && provider.isAvailable) {
        this.log('debug', `🎯 Using user task override for ${taskType}: ${override.provider}`);
        return provider;
      } else {
        this.log('info', `⚠️ User's task override ${override.provider} not available, finding fallback`);
      }
    }

    // Check user's provider preferences
    const availableProviders = this.getAvailableProviders();
    const enabledProviders = availableProviders.filter(provider => {
      const preference = this.userSettings!.providerPreferences[provider.name];
      return preference?.enabled !== false;
    });

    if (enabledProviders.length === 0) {
      return this.getDefaultProvider();
    }

    // Sort by user's priority preferences
    const sortedProviders = enabledProviders.sort((a, b) => {
      const priorityA = this.userSettings!.providerPreferences[a.name]?.priority || 999;
      const priorityB = this.userSettings!.providerPreferences[b.name]?.priority || 999;
      return priorityA - priorityB;
    });

    const bestProvider = sortedProviders[0];
    this.log('debug', `🎯 Using user's preferred provider for ${taskType}: ${bestProvider.name}`);
    return bestProvider;
  }

  /**
   * Get default provider (always OpenAI if available)
   */
  public getDefaultProvider(): LLMProviderConfig | null {
    const openai = this.getProvider('openai');
    if (openai && openai.isAvailable) {
      this.log('debug', '🔄 Using default provider: openai');
      return openai;
    }

    // If OpenAI is not available, get any available provider
    const available = this.getAvailableProviders();
    if (available.length > 0) {
      this.log('warn', `⚠️ OpenAI not available, using first available: ${available[0].name}`);
      return available[0];
    }

    this.log('error', '❌ No LLM providers available!');
    return null;
  }

  /**
   * Task-specific provider recommendations
   */
  private getTaskRecommendations(): Record<string, string> {
    return {
      // 🚀 Speed-focused tasks
      realtime: 'groq',
      streaming: 'groq',
      simple_tasks: 'groq',
      
      // 🧠 Reasoning-focused tasks
      research: 'mistral',
      analysis: 'mistral',
      problem_solving: 'mistral',
      
      // ✍️ Creativity-focused tasks
      writing: 'anthropic',
      content_creation: 'anthropic',
      storytelling: 'anthropic',
      
      // 💻 Coding-focused tasks
      code: 'openai',
      code_review: 'openai',
      debugging: 'openai',
      
      // 🌍 Multilingual tasks
      translation: 'google',
      multilingual: 'google',
      
      // 💰 Cost-effective tasks
      conversation: 'openai',
      summarization: 'anthropic',
      
      // 🎯 Specialized tasks
      document_processing: 'anthropic',
      email_processing: 'anthropic',
      
      // 🏠 Local tasks
      local: 'ollama',
      
      // Default
      default: 'openai'
    };
  }

  /**
   * Check if Ollama is running locally
   */
  public async checkOllamaAvailability(): Promise<boolean> {
    const ollamaProvider = this.getProvider('ollama');
    if (!ollamaProvider) return false;

    try {
      const response = await fetch(`${ollamaProvider.baseUrl}/api/tags`, {
        method: 'GET',
        signal: AbortSignal.timeout(2000) // 2 second timeout
      });
      
      const isAvailable = response.ok;
      ollamaProvider.isAvailable = isAvailable;
      
      if (isAvailable) {
        this.log('info', '🏠 Ollama is available locally');
      }
      
      return isAvailable;
    } catch (error) {
      ollamaProvider.isAvailable = false;
      return false;
    }
  }

  /**
   * Update provider availability status
   */
  public updateProviderAvailability(name: string, isAvailable: boolean): void {
    const provider = this.getProvider(name);
    if (provider) {
      provider.isAvailable = isAvailable;
      this.log('debug', `📊 Updated ${name} availability: ${isAvailable}`);
    }
  }

  /**
   * Get provider statistics
   */
  public getProviderStats(): {
    total: number;
    available: number;
    unavailable: string[];
    availableList: string[];
  } {
    const all = Array.from(this.providers.values());
    const available = all.filter(p => p.isAvailable);
    const unavailable = all.filter(p => !p.isAvailable).map(p => p.name);
    
    return {
      total: all.length,
      available: available.length,
      unavailable,
      availableList: available.map(p => p.name)
    };
  }

  /**
   * Log provider availability
   */
  private logAvailableProviders(): void {
    const stats = this.getProviderStats();
    
    this.log('info', `📊 Provider Status: ${stats.available}/${stats.total} available`);
    
    if (stats.availableList.length > 0) {
      this.log('info', `✅ Available: ${stats.availableList.join(', ')}`);
    }
    
    if (stats.unavailable.length > 0) {
      this.log('info', `⚠️ Unavailable: ${stats.unavailable.join(', ')}`);
    }
  }

  /**
   * Logging utility
   */
  private log(level: string, message: string): void {
    if (this.options.logLevel === 'silent') return;
    if (this.options.logLevel === 'info' && level === 'debug') return;
    
    const emoji = level === 'error' ? '❌' : level === 'warn' ? '⚠️' : level === 'info' ? 'ℹ️' : '🐛';
    console.log(`${emoji} [LLMConfigManager] ${message}`);
  }

  /**
   * Get configuration summary for debugging
   */
  public getConfigSummary(): string {
    const stats = this.getProviderStats();
    const available = stats.availableList.join(', ');
    const unavailable = stats.unavailable.join(', ');
    
    return `
🔧 LLM Configuration Summary:
├─ Total Providers: ${stats.total}
├─ Available: ${stats.available} (${available})
├─ Unavailable: ${stats.unavailable.length} (${unavailable})
├─ Default Provider: ${this.options.defaultProvider}
├─ Fallbacks Enabled: ${this.options.enableFallbacks}
└─ Log Level: ${this.options.logLevel}
    `.trim();
  }
}

// Export singleton instance
export const llmConfigManager = LLMConfigManager.getInstance();
