// Pinecone client with graceful fallback for missing dependencies
let PineconeClient: any = null;

try {
  const { Pinecone } = require('@pinecone-database/pinecone');
  PineconeClient = Pinecone;
} catch (error) {
  console.warn('Pinecone client not available, using mock client');
}

export class PineconeVectorStore {
  private client: any = null;
  private index: any = null;
  private isAvailable: boolean = !!PineconeClient;

  constructor(apiKey?: string, environment?: string) {
    if (this.isAvailable && apiKey) {
      try {
        // New Pinecone client format
        this.client = new PineconeClient({ 
          apiKey: apiKey,
          environment: environment 
        });
        console.log('✅ Pinecone client initialized successfully');
      } catch (error) {
        console.error('Failed to initialize Pinecone client:', error);
        this.isAvailable = false;
      }
    } else if (!apiKey) {
      console.warn('⚠️ Pinecone API key not provided, using mock client');
    }
  }

  async initializeIndex(indexName: string) {
    if (!this.isAvailable) {
      console.warn('Pinecone not available, simulating index initialization:', indexName);
      return;
    }

    try {
      this.index = this.client.index(indexName);
    } catch (error) {
      console.error('Failed to initialize Pinecone index:', error);
      throw error;
    }
  }

  async upsert(vectors: any[]) {
    if (!this.isAvailable || !this.index) {
      console.warn('Pinecone not available, simulating vector upsert:', vectors.length, 'vectors');
      return Promise.resolve();
    }

    try {
      await this.index.upsert(vectors);
    } catch (error) {
      console.error('Vector upsert failed:', error);
      throw error;
    }
  }

  async query(queryVector: number[], topK: number = 10, filter?: any) {
    if (!this.isAvailable || !this.index) {
      console.warn('Pinecone not available, simulating vector query');
      return { matches: [] };
    }

    try {
      const queryRequest = {
        vector: queryVector,
        topK,
        includeMetadata: true
      };

      if (filter) {
        queryRequest.filter = filter;
      }

      const result = await this.index.query(queryRequest);
      return result;
    } catch (error) {
      console.error('Vector query failed:', error);
      throw error;
    }
  }

  async delete(ids: string[]) {
    if (!this.isAvailable || !this.index) {
      console.warn('Pinecone not available, simulating vector deletion:', ids);
      return Promise.resolve();
    }

    try {
      await this.index.deleteMany(ids);
    } catch (error) {
      console.error('Vector deletion failed:', error);
      throw error;
    }
  }

  async describeIndexStats() {
    if (!this.isAvailable || !this.index) {
      console.warn('Pinecone not available, simulating index stats');
      return { totalVectorCount: 0 };
    }

    try {
      return await this.index.describeIndexStats();
    } catch (error) {
      console.error('Failed to get index stats:', error);
      throw error;
    }
  }

  isPineconeAvailable(): boolean {
    return this.isAvailable;
  }
}

// Default client instance with environment variables
export const getVectorStore = () => {
  const apiKey = import.meta.env.VITE_PINECONE_API_KEY;
  const environment = import.meta.env.VITE_PINECONE_ENVIRONMENT;
  
  if (!apiKey) {
    console.warn('Pinecone API key not configured');
    return new PineconeVectorStore();
  }
  
  return new PineconeVectorStore(apiKey, environment);
};

export const vectorStore = getVectorStore();