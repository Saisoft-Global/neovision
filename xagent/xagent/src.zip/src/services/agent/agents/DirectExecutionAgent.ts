import { BaseAgent } from '../BaseAgent';
import type { AgentConfig, AgentRequest, AgentResponse } from '../../../types/agent-framework';
import { createChatCompletion } from '../../openai/chat';

export class DirectExecutionAgent extends BaseAgent {
  constructor(id: string, config: AgentConfig) {
    super(id, config);
    this.type = 'direct_execution';
    this.name = 'Direct Execution Agent';
    this.description = 'Handles direct execution of simple tasks without complex routing';
  }

  async process(request: AgentRequest): Promise<AgentResponse> {
    try {
      console.log(`🎯 DirectExecutionAgent processing: ${request.message}`);

      // For direct execution, we simply use the OpenAI chat completion
      // This is useful for simple conversational tasks that don't need complex routing
      const response = await createChatCompletion([
        {
          role: 'system',
          content: `You are a helpful AI assistant that can handle direct execution of tasks. 
          
          Your capabilities include:
          - Answering questions and providing information
          - Helping with general tasks and problem-solving
          - Explaining concepts and providing guidance
          - Assisting with planning and organization
          
          Be helpful, accurate, and concise in your responses. If the user asks for something that requires browser automation or complex multi-step processes, acknowledge their request and explain that those features are being developed.`
        },
        {
          role: 'user',
          content: request.message
        }
      ]);

      if (response?.choices?.[0]?.message?.content) {
        return {
          success: true,
          data: {
            message: response.choices[0].message.content,
            agentId: this.id,
            agentType: this.type,
            timestamp: new Date().toISOString()
          },
          metadata: {
            processingTime: Date.now() - Date.now(),
            tokensUsed: response.usage?.total_tokens || 0
          }
        };
      } else {
        throw new Error('No response from AI');
      }
    } catch (error) {
      console.error('DirectExecutionAgent error:', error);
      return {
        success: false,
        data: null,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        metadata: {
          agentId: this.id,
          agentType: this.type,
          timestamp: new Date().toISOString()
        }
      };
    }
  }

  async initialize(): Promise<void> {
    console.log(`✅ DirectExecutionAgent ${this.id} initialized`);
  }

  async cleanup(): Promise<void> {
    console.log(`🧹 DirectExecutionAgent ${this.id} cleaned up`);
  }
}
