import { BaseAgent } from './BaseAgent';
import type { AgentConfig } from '../../types/agent-framework';
import type { AgentResponse } from './types';
import type { ToolRegistry } from '../tools/ToolRegistry';
import type { ToolAttachment, IntentAnalysis, SkillExecutionResult } from '../../types/tool-framework';
import { createChatCompletion } from '../openai/chat';

/**
 * Enhanced Agent with dynamic tool and skill support
 * 
 * This agent can:
 * - Attach tools dynamically
 * - Execute skills from natural language prompts
 * - Automatically map user intent to appropriate skills
 * - Handle multiple tools simultaneously
 */
export class ToolEnabledAgent extends BaseAgent {
  private toolRegistry: ToolRegistry;
  private attachedTools: Map<string, ToolAttachment> = new Map();
  
  constructor(id: string, config: AgentConfig, toolRegistry: ToolRegistry) {
    super(id, config);
    this.toolRegistry = toolRegistry;
  }
  
  /**
   * Attach a tool to this agent
   * Automatically adds tool skills to agent's skill list
   */
  public attachTool(toolId: string, permissions?: string[]): void {
    const tool = this.toolRegistry.getTool(toolId);
    
    if (!tool) {
      throw new Error(`Tool not found: ${toolId}`);
    }
    
    if (!tool.isActive) {
      throw new Error(`Tool is not active: ${tool.name}`);
    }
    
    // Record attachment
    this.attachedTools.set(toolId, {
      toolId,
      attachedAt: new Date().toISOString(),
      permissions
    });
    
    // Add tool skills to agent configuration
    for (const skill of tool.skills) {
      // Check if skill already exists
      const exists = this.config.skills.some(s => s.name === skill.name);
      if (!exists) {
        this.config.skills.push({
          name: skill.name,
          level: 5, // Tool skills are always expert level
          config: {
            toolId: tool.id,
            toolName: tool.name,
            description: skill.description,
            parameters: skill.parameters
          }
        });
      }
    }
    
    console.log(`✅ Tool attached to agent: ${tool.name} (${tool.skills.length} skills added)`);
  }
  
  /**
   * Detach a tool from this agent
   */
  public detachTool(toolId: string): void {
    const attachment = this.attachedTools.get(toolId);
    if (!attachment) {
      throw new Error(`Tool not attached: ${toolId}`);
    }
    
    // Remove tool skills from agent
    const tool = this.toolRegistry.getTool(toolId);
    if (tool) {
      const toolSkillNames = tool.skills.map(s => s.name);
      this.config.skills = this.config.skills.filter(
        skill => !toolSkillNames.includes(skill.name)
      );
    }
    
    // Remove attachment record
    this.attachedTools.delete(toolId);
    
    console.log(`🗑️  Tool detached from agent: ${toolId}`);
  }
  
  /**
   * Get all attached tools
   */
  public getAttachedTools(): ToolAttachment[] {
    return Array.from(this.attachedTools.values());
  }
  
  /**
   * Get all available skill names (core + tool skills)
   */
  public getAvailableSkills(): string[] {
    return this.config.skills.map(s => s.name);
  }
  
  /**
   * Execute a skill directly by name
   */
  public async executeSkill(
    skillName: string,
    params: Record<string, any>,
    context?: any
  ): Promise<SkillExecutionResult> {
    // Check if agent has this skill
    if (!this.hasSkill(skillName)) {
      return {
        success: false,
        error: `Agent does not have skill: ${skillName}`
      };
    }
    
    // Execute via tool registry
    return await this.toolRegistry.executeSkill(skillName, params, context);
  }
  
  /**
   * Execute based on natural language prompt
   * Agent automatically determines which skill to use and extracts parameters
   */
  public async executeFromPrompt(
    prompt: string,
    context: any = {}
  ): Promise<SkillExecutionResult> {
    try {
      // Step 1: Analyze intent and determine which skill to use
      const intent = await this.analyzeIntent(prompt, context);
      
      if (!intent.skillName) {
        return {
          success: false,
          error: 'Could not determine intent from prompt'
        };
      }
      
      console.log(`🎯 Intent detected: ${intent.skillName} (confidence: ${intent.confidence})`);
      
      // Step 2: Check if agent has the required skill
      if (!this.hasSkill(intent.skillName)) {
        return {
          success: false,
          error: `Agent does not have required skill: ${intent.skillName}`
        };
      }
      
      // Step 3: Execute the skill with extracted parameters
      const result = await this.executeSkill(intent.skillName, intent.parameters, context);
      
      return {
        ...result,
        metadata: {
          ...result.metadata,
          intent: {
            skillName: intent.skillName,
            confidence: intent.confidence,
            reasoning: intent.reasoning
          }
        }
      };
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      return {
        success: false,
        error: `Failed to execute from prompt: ${errorMessage}`
      };
    }
  }
  
  /**
   * Analyze user intent and determine which skill to use
   */
  private async analyzeIntent(prompt: string, context: any): Promise<IntentAnalysis> {
    const availableSkills = this.getAvailableSkills();
    const skillDetails = this.config.skills
      .filter(s => availableSkills.includes(s.name))
      .map(s => ({
        name: s.name,
        description: (s.config as any)?.description || '',
        parameters: (s.config as any)?.parameters || []
      }));
    
    const response = await createChatCompletion([
      {
        role: 'system',
        content: `You are an AI agent intent analyzer. Analyze user requests and determine which skill to use.

Available skills:
${JSON.stringify(skillDetails, null, 2)}

Context:
${JSON.stringify(context, null, 2)}

Analyze the user's prompt and return JSON with:
- skillName (string): The most appropriate skill to use
- confidence (number): Confidence level 0-1
- parameters (object): Extracted parameters for the skill
- reasoning (string): Brief explanation of your choice`
      },
      {
        role: 'user',
        content: prompt
      }
    ], this.config.llm_config);
    
    try {
      const content = response.choices[0].message.content || '{}';
      const analysis = JSON.parse(content);
      
      return {
        skillName: analysis.skillName || '',
        confidence: analysis.confidence || 0,
        parameters: analysis.parameters || {},
        reasoning: analysis.reasoning || ''
      };
    } catch (error) {
      console.error('Intent analysis failed:', error);
      return {
        skillName: '',
        confidence: 0,
        parameters: {},
        reasoning: 'Failed to parse intent'
      };
    }
  }
  
  /**
   * Generate a natural language response after skill execution
   */
  public async generateResponseFromResult(
    prompt: string,
    result: SkillExecutionResult
  ): Promise<string> {
    const response = await createChatCompletion([
      {
        role: 'system',
        content: `You are a helpful AI agent. The user asked: "${prompt}"
        
You executed a skill and got this result:
${JSON.stringify(result, null, 2)}

Generate a natural, conversational response to the user explaining what you did and the result.
Be concise but informative.`
      },
      {
        role: 'user',
        content: 'Please provide the response.'
      }
    ], this.config.llm_config);
    
    return response.choices[0].message.content || 'Task completed.';
  }
  
  /**
   * Execute action (required by BaseAgent)
   */
  async execute(action: string, params: Record<string, unknown>): Promise<AgentResponse> {
    // Check if this is a skill execution
    if (this.hasSkill(action)) {
      const result = await this.executeSkill(action, params as any);
      return {
        success: result.success,
        data: result.data,
        error: result.error
      };
    }
    
    // Otherwise, treat as natural language prompt
    const prompt = `${action} ${JSON.stringify(params)}`;
    const result = await this.executeFromPrompt(prompt);
    
    return {
      success: result.success,
      data: result.data,
      error: result.error
    };
  }
  
  /**
   * Get agent statistics
   */
  public getStatistics() {
    const coreSkills = this.getCoreCapabilities();
    const toolSkills = this.config.skills.filter(
      s => !coreSkills.includes(s.name)
    );
    
    return {
      agentId: this.id,
      totalSkills: this.config.skills.length,
      coreSkills: coreSkills.length,
      toolSkills: toolSkills.length,
      attachedTools: this.attachedTools.size,
      tools: this.getAttachedTools()
    };
  }
}




