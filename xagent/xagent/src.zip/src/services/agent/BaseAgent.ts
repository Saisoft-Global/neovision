import type { AgentConfig, LLMConfig, AgentSkill } from '../../types/agent-framework';
import type { AgentContext, AgentResponse } from './types';
import { createChatCompletion } from '../openai/chat';
import { WorkflowMatcher } from '../workflow/WorkflowMatcher';
import { EnhancedWorkflowExecutor } from '../workflow/EnhancedWorkflowExecutor';
import { CapabilityManager } from './CapabilityManager';
import { LLMRouter, LLMMessage } from '../llm/LLMRouter';
import type { AgentCapability } from '../../types/agent-framework';
import { VectorSearchService } from '../vectorization/VectorSearchService';
import { KnowledgeGraphManager } from '../knowledge/graph/KnowledgeGraphManager';
import { MemoryService } from '../memory/MemoryService';
import { generateEmbeddings } from '../openai/embeddings';

// RAG Context for every agent interaction
export interface RAGContext {
  vectorResults: Array<{ content: string; score: number; metadata: any }>;
  graphResults: Array<{ nodes: any[]; relations: any[] }>;
  memories: Array<{ content: string; type: string; importance: number }>;
  summarizedHistory: string;
  tokenUsage: { original: number; optimized: number; savings: number };
}

export abstract class BaseAgent {
  protected id: string;
  protected config: AgentConfig;
  protected workflowMatcher: WorkflowMatcher;
  protected workflowExecutor: EnhancedWorkflowExecutor;
  protected capabilityManager: CapabilityManager;
  protected llmRouter: LLMRouter;
  protected capabilities: AgentCapability[] = [];
  protected isInitialized: boolean = false;
  
  // RAG Components - ALWAYS ACTIVE
  protected vectorSearch: VectorSearchService;
  protected knowledgeGraph: KnowledgeGraphManager;
  protected memoryService: MemoryService;

  constructor(id: string, config: AgentConfig) {
    this.id = id;
    this.config = config;
    this.workflowMatcher = WorkflowMatcher.getInstance();
    this.workflowExecutor = new EnhancedWorkflowExecutor();
    this.capabilityManager = new CapabilityManager(id);
    this.llmRouter = LLMRouter.getInstance();
    
    // Initialize RAG components - ALWAYS ACTIVE
    this.vectorSearch = VectorSearchService.getInstance();
    this.knowledgeGraph = KnowledgeGraphManager.getInstance();
    this.memoryService = MemoryService.getInstance();
    
    // Auto-initialize capabilities in background
    this.initialize().catch(err => {
      console.warn('Failed to initialize capabilities:', err);
    });
  }

  /**
   * Initialize agent and discover capabilities dynamically
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    try {
      console.log(`🚀 Initializing agent capabilities: ${this.id}`);
      this.capabilities = await this.capabilityManager.discoverCapabilities();
      console.log(`✅ Agent ${this.id} initialized with ${this.capabilities.length} capabilities`);
      this.isInitialized = true;
    } catch (error) {
      console.error('Error initializing capabilities:', error);
      // Continue without capabilities rather than failing
      this.isInitialized = true;
    }
  }

  /**
   * Get all skills including core intelligence skills
   */
  public getSkills() {
    return this.config.skills;
  }

  /**
   * Check if agent has a specific skill
   */
  public hasSkill(skillName: string, minLevel: number = 1): boolean {
    const skill = this.config.skills.find(s => s.name === skillName);
    return skill !== undefined && skill.level >= minLevel;
  }

  /**
   * Get core intelligence capabilities
   * These are the fundamental skills every agent has for understanding and completing work
   */
  public getCoreCapabilities(): string[] {
    const coreSkills = this.config.skills.filter(skill => 
      ['natural_language_understanding', 'natural_language_generation', 
       'task_comprehension', 'reasoning', 'context_retention'].includes(skill.name)
    );
    
    return coreSkills.map(skill => skill.name);
  }

  /**
   * Process user message - intelligently checks for workflow triggers
   * This is the main entry point for agent message handling
   */
  async processMessage(message: string, context: any = {}): Promise<string> {
    try {
      // 1. Check if this message should trigger a workflow
      const workflowMatch = await this.checkForWorkflowTrigger(message, context);

      // 2. If workflow found with high confidence, execute it
      if (workflowMatch && workflowMatch.confidence >= 0.7) {
        console.log(`🔄 [${this.constructor.name}] Triggering workflow: ${workflowMatch.workflow.name}`);
        return await this.executeWorkflowAndRespond(workflowMatch.workflow, message, context);
      }

      // 3. Otherwise, use normal AI response generation
      return await this.generateResponse(message, context);
    } catch (error) {
      console.error('Error processing message:', error);
      return `I encountered an error processing your request. ${error instanceof Error ? error.message : 'Please try again.'}`;
    }
  }

  /**
   * Check if message triggers any of this agent's workflows
   */
  protected async checkForWorkflowTrigger(message: string, context: any) {
    try {
      return await this.workflowMatcher.findWorkflowForIntent(
        this.id,
        message,
        context
      );
    } catch (error) {
      console.error('Error checking workflow trigger:', error);
      return null;
    }
  }

  /**
   * Execute workflow and generate human-friendly response
   */
  protected async executeWorkflowAndRespond(
    workflow: any,
    message: string,
    context: any
  ): Promise<string> {
    const executionContext = {
      userId: context.userId || 'default',
      agentId: this.id,
      inputData: {
        message,
        ...this.extractDataFromPrompt(message),
        ...context,
      },
      credentials: await this.getAPICredentials(),
    };

    console.log(`🚀 Executing workflow: ${workflow.name}`);
    
    const result = await this.workflowExecutor.executeWorkflow(workflow, executionContext);

    if (result.success) {
      return this.formatWorkflowSuccess(workflow, result);
    } else {
      return this.formatWorkflowFailure(workflow, result);
    }
  }

  /**
   * Extract structured data from natural language prompt
   */
  protected extractDataFromPrompt(message: string): Record<string, unknown> {
    const data: Record<string, unknown> = {};

    // Extract common patterns
    const emailMatch = message.match(/[\w.-]+@[\w.-]+\.\w+/);
    if (emailMatch) data.email = emailMatch[0];

    const nameMatch = message.match(/(?:named?|called)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/i);
    if (nameMatch) {
      const fullName = nameMatch[1];
      const parts = fullName.split(' ');
      data.full_name = fullName;
      data.first_name = parts[0];
      if (parts.length > 1) data.last_name = parts.slice(1).join(' ');
    }

    const companyMatch = message.match(/(?:from|at|company|for)\s+([A-Z][a-zA-Z\s&]+)(?:\.|,|$)/);
    if (companyMatch) data.company = companyMatch[1].trim();

    return data;
  }

  /**
   * Get API credentials for third-party integrations
   * Override in subclasses for agent-specific credentials
   */
  protected async getAPICredentials(): Promise<any> {
    return {
      google: import.meta.env.VITE_GOOGLE_WORKSPACE_ACCESS_TOKEN ? {
        accessToken: import.meta.env.VITE_GOOGLE_WORKSPACE_ACCESS_TOKEN,
      } : null,
      salesforce: import.meta.env.VITE_SALESFORCE_ACCESS_TOKEN ? {
        accessToken: import.meta.env.VITE_SALESFORCE_ACCESS_TOKEN,
        instanceUrl: import.meta.env.VITE_SALESFORCE_INSTANCE_URL,
      } : null,
      hrSystem: import.meta.env.VITE_HR_SYSTEM_API_KEY ? {
        apiKey: import.meta.env.VITE_HR_SYSTEM_API_KEY,
        domain: import.meta.env.VITE_HR_SYSTEM_DOMAIN,
      } : null,
    };
  }

  /**
   * Format successful workflow execution
   */
  protected formatWorkflowSuccess(workflow: any, result: any): string {
    const successNodes = result.nodeResults.filter((r: any) => r.success);
    return `✅ ${workflow.name} completed successfully!

Steps executed:
${successNodes.map((n: any) => `  ✓ ${n.nodeName}`).join('\n')}

Execution time: ${result.executionTime}ms`;
  }

  /**
   * Format workflow failure
   */
  protected formatWorkflowFailure(workflow: any, result: any): string {
    const failedNode = result.nodeResults.find((r: any) => !r.success);
    return `❌ Workflow "${workflow.name}" encountered an error at step: ${failedNode?.nodeName}

Error: ${result.error || failedNode?.error}

Would you like me to try again or handle this manually?`;
  }

  /**
   * Select appropriate LLM based on skill being used
   */
  protected selectLLMForTask(skillName?: string): LLMConfig {
    // If skill is specified and has preferred LLM, use it
    if (skillName) {
      const skill = this.config.skills.find(s => s.name === skillName);
      if (skill?.preferred_llm) {
        console.log(`🎯 Using skill-preferred LLM: ${skill.preferred_llm.provider}/${skill.preferred_llm.model}`);
        return skill.preferred_llm;
      }

      // Check for task-specific override
      const llm = this.llmRouter.selectLLMForSkill(
        skill || { name: skillName, level: 3 },
        this.config.llm_config,
        this.config.llm_overrides
      );
      return llm;
    }

    // Use default LLM
    return this.config.llm_config;
  }

  /**
   * Execute LLM request with intelligent routing
   */
  protected async executeLLM(
    messages: LLMMessage[],
    skillName?: string
  ): Promise<string> {
    // Select appropriate LLM
    const llmConfig = this.selectLLMForTask(skillName);
    
    // Get fallback LLM
    const fallback = this.config.fallback_llm || {
      provider: 'openai' as const,
      model: 'gpt-3.5-turbo'
    };

    try {
      // Execute with LLM Router
      return await this.llmRouter.execute(messages, llmConfig, fallback);
    } catch (error) {
      console.error('LLM execution error:', error);
      throw error;
    }
  }

  protected async generateResponse(
    prompt: string,
    context: AgentContext
  ): Promise<string> {
    const systemPrompt = this.buildSystemPrompt(context);
    
    // Use LLM Router for intelligent routing
    const messages: LLMMessage[] = [
      {
        role: 'system',
        content: systemPrompt,
      },
      {
        role: 'user',
        content: prompt,
      },
    ];

    // Determine which skill is being used (if any)
    const skillName = this.detectSkillFromContext(context);

    return await this.executeLLM(messages, skillName);
  }

  /**
   * Detect which skill is being used from context
   */
  private detectSkillFromContext(context: AgentContext): string | undefined {
    // Simple detection based on context type
    const type = context.type?.toLowerCase() || '';
    
    if (type.includes('research') || type.includes('analysis')) return 'research_analysis';
    if (type.includes('writ') || type.includes('content')) return 'content_writing';
    if (type.includes('code')) return 'code_generation';
    if (type.includes('support')) return 'customer_support';
    
    return undefined;
  }

  private buildSystemPrompt(context: AgentContext): string {
    const { personality, skills } = this.config;
    
    // Include skills in system prompt to make agent aware of its capabilities
    const skillsList = skills
      .filter(s => s.level >= 3) // Only include proficient skills (level 3+)
      .map(s => `${s.name} (Level ${s.level})`)
      .join(', ');
    
    return `You are an AI assistant specializing in ${context.type} with expertise in: ${context.expertise.join(', ')}.

Personality traits:
- Friendliness: ${personality.friendliness * 100}%
- Formality: ${personality.formality * 100}%
- Proactiveness: ${personality.proactiveness * 100}%
- Detail orientation: ${personality.detail_orientation * 100}%

Your skills and capabilities: ${skillsList}

You have advanced natural language understanding, task comprehension, reasoning, and context retention abilities. Use these to understand user intent deeply and provide intelligent, contextual responses.

Adjust your communication style according to your personality traits.`;
  }

  /**
   * Get available capabilities
   */
  getAvailableCapabilities(): AgentCapability[] {
    return this.capabilities.filter(cap => cap.isAvailable);
  }

  /**
   * Check if agent has a specific capability
   */
  hasCapability(capabilityId: string): boolean {
    return this.capabilityManager.hasCapability(capabilityId);
  }

  /**
   * ✨ RAG-POWERED INTERACTION
   * This method is called for EVERY agent interaction
   * It automatically enriches context using Vector Search + Knowledge Graph + Memory
   */
  protected async buildRAGContext(
    userMessage: string,
    conversationHistory: Array<{ role: string; content: string }>,
    userId: string
  ): Promise<RAGContext> {
    console.log(`🧠 Building RAG context for: "${userMessage.substring(0, 50)}..."`);
    
    try {
      // Run all RAG components in parallel for speed
      const [vectorResults, graphResults, memories, summarizedHistory] = await Promise.all([
        this.searchVectorStore(userMessage, userId),
        this.searchKnowledgeGraph(userMessage, userId),
        this.searchMemories(userMessage, userId),
        this.summarizeConversation(conversationHistory)
      ]);

      // Calculate token savings
      const originalTokens = this.estimateTokens(JSON.stringify(conversationHistory));
      const optimizedTokens = this.estimateTokens(summarizedHistory);
      const savings = originalTokens - optimizedTokens;

      const ragContext: RAGContext = {
        vectorResults,
        graphResults,
        memories,
        summarizedHistory,
        tokenUsage: {
          original: originalTokens,
          optimized: optimizedTokens,
          savings: Math.max(0, savings)
        }
      };

      console.log(`✅ RAG Context built:`, {
        vectorResults: vectorResults.length,
        graphNodes: graphResults.flatMap(r => r.nodes).length,
        memories: memories.length,
        tokenSavings: ragContext.tokenUsage.savings
      });

      return ragContext;

    } catch (error) {
      console.error('RAG context building error:', error);
      // Return empty context on error
      return {
        vectorResults: [],
        graphResults: [],
        memories: [],
        summarizedHistory: conversationHistory.map(m => `${m.role}: ${m.content}`).join('\n'),
        tokenUsage: { original: 0, optimized: 0, savings: 0 }
      };
    }
  }

  /**
   * Search vector store for relevant documents
   */
  private async searchVectorStore(query: string, userId: string): Promise<Array<{ content: string; score: number; metadata: any }>> {
    try {
      const results = await this.vectorSearch.searchSimilarDocuments(query, {
        filter: { userId },
        topK: 5,
        threshold: 0.7
      });

      return results.map(r => ({
        content: r.content,
        score: r.score,
        metadata: r.metadata
      }));
    } catch (error) {
      console.error('Vector search error:', error);
      return [];
    }
  }

  /**
   * Search knowledge graph for relevant entities and relationships
   */
  private async searchKnowledgeGraph(query: string, userId: string): Promise<Array<{ nodes: any[]; relations: any[] }>> {
    try {
      const result = await this.knowledgeGraph.semanticSearch({
        text: query,
        intent: 'find_entities',
        filters: { userId },
        limit: 5
      });

      return [{
        nodes: result.nodes,
        relations: result.relations
      }];
    } catch (error) {
      console.error('Knowledge graph search error:', error);
      return [];
    }
  }

  /**
   * Search memories for relevant past interactions
   */
  private async searchMemories(query: string, userId: string): Promise<Array<{ content: string; type: string; importance: number }>> {
    try {
      const results = await this.memoryService.searchMemories(query, userId, {
        limit: 5,
        threshold: 0.7
      });

      return results.map(r => ({
        content: r.content,
        type: r.type || 'unknown',
        importance: r.score || 0.5
      }));
    } catch (error) {
      console.error('Memory search error:', error);
      return [];
    }
  }

  /**
   * Summarize conversation history to optimize tokens
   */
  private async summarizeConversation(history: Array<{ role: string; content: string }>): Promise<string> {
    try {
      // If history is short, no need to summarize
      if (history.length <= 4) {
        return history.map(m => `${m.role}: ${m.content}`).join('\n');
      }

      // Keep recent messages (last 2) and summarize older ones
      const recentMessages = history.slice(-2);
      const olderMessages = history.slice(0, -2);

      if (olderMessages.length === 0) {
        return history.map(m => `${m.role}: ${m.content}`).join('\n');
      }

      // Summarize older messages
      const summaryPrompt = `Summarize this conversation history concisely, preserving key information:

${olderMessages.map(m => `${m.role}: ${m.content}`).join('\n')}

Provide a brief summary in 2-3 sentences.`;

      const summary = await createChatCompletion([
        { role: 'system', content: 'You are an expert at summarizing conversations concisely.' },
        { role: 'user', content: summaryPrompt }
      ]);

      // Combine summary with recent messages
      return `[Previous conversation summary: ${summary}]\n\n${recentMessages.map(m => `${m.role}: ${m.content}`).join('\n')}`;

    } catch (error) {
      console.error('Conversation summarization error:', error);
      return history.map(m => `${m.role}: ${m.content}`).join('\n');
    }
  }

  /**
   * Estimate token count (rough approximation)
   */
  private estimateTokens(text: string): number {
    // Rough estimate: 1 token ≈ 4 characters
    return Math.ceil(text.length / 4);
  }

  /**
   * ✨ ENHANCED: Generate response with full RAG context
   */
  protected async generateResponseWithRAG(
    userMessage: string,
    conversationHistory: Array<{ role: string; content: string }>,
    userId: string,
    context: AgentContext
  ): Promise<string> {
    try {
      console.log(`💬 Generating RAG-powered response...`);

      // 1. Build RAG context (Vector + Graph + Memory + Summary)
      const ragContext = await this.buildRAGContext(userMessage, conversationHistory, userId);

      // 2. Build enhanced system prompt with RAG context
      const systemPrompt = this.buildSystemPromptWithRAG(context, ragContext);

      // 3. Build user message with RAG context
      const enhancedUserMessage = this.buildUserMessageWithRAG(userMessage, ragContext);

      // 4. Generate response using LLM
      const messages: LLMMessage[] = [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: enhancedUserMessage }
      ];

      const skillName = this.detectSkillFromContext(context);
      const response = await this.executeLLM(messages, skillName);

      // 5. Store interaction in memory for future use
      await this.storeInteraction(userId, userMessage, response, ragContext);

      console.log(`✅ RAG-powered response generated (${ragContext.tokenUsage.savings} tokens saved)`);

      return response;

    } catch (error) {
      console.error('RAG-powered response generation error:', error);
      throw error;
    }
  }

  /**
   * Build system prompt with RAG context
   */
  private buildSystemPromptWithRAG(context: AgentContext, ragContext: RAGContext): string {
    const basePrompt = this.buildSystemPrompt(context);

    // Add RAG context to system prompt
    let ragPrompt = basePrompt + '\n\n';

    // Add relevant documents from vector search
    if (ragContext.vectorResults.length > 0) {
      ragPrompt += `\n📚 RELEVANT DOCUMENTS:\n`;
      ragContext.vectorResults.forEach((doc, i) => {
        ragPrompt += `${i + 1}. ${doc.content.substring(0, 200)}... (relevance: ${(doc.score * 100).toFixed(0)}%)\n`;
      });
    }

    // Add knowledge from knowledge graph
    if (ragContext.graphResults.length > 0 && ragContext.graphResults[0].nodes.length > 0) {
      ragPrompt += `\n🧠 KNOWLEDGE GRAPH:\n`;
      const nodes = ragContext.graphResults[0].nodes.slice(0, 5);
      nodes.forEach(node => {
        ragPrompt += `- ${node.label}: ${node.type}\n`;
      });
    }

    // Add relevant memories
    if (ragContext.memories.length > 0) {
      ragPrompt += `\n💭 RELEVANT MEMORIES:\n`;
      ragContext.memories.forEach((mem, i) => {
        ragPrompt += `${i + 1}. ${mem.content.substring(0, 150)}... (${mem.type})\n`;
      });
    }

    // Add conversation summary
    if (ragContext.summarizedHistory) {
      ragPrompt += `\n📝 CONVERSATION CONTEXT:\n${ragContext.summarizedHistory}\n`;
    }

    ragPrompt += `\nUse the above context to provide accurate, contextual responses.`;

    return ragPrompt;
  }

  /**
   * Build user message with RAG context hints
   */
  private buildUserMessageWithRAG(userMessage: string, ragContext: RAGContext): string {
    let enhancedMessage = userMessage;

    // Add context hints if relevant information was found
    if (ragContext.vectorResults.length > 0 || ragContext.memories.length > 0) {
      enhancedMessage += `\n\n[Note: I have access to ${ragContext.vectorResults.length} relevant documents and ${ragContext.memories.length} memories that may help answer this question.]`;
    }

    return enhancedMessage;
  }

  /**
   * Store interaction for future RAG retrieval
   */
  private async storeInteraction(
    userId: string,
    userMessage: string,
    agentResponse: string,
    ragContext: RAGContext
  ): Promise<void> {
    try {
      // Store in memory service
      await this.memoryService.storeMemory({
        userId,
        type: 'conversation',
        content: {
          userMessage,
          agentResponse,
          timestamp: new Date().toISOString(),
          agentId: this.id,
          tokenSavings: ragContext.tokenUsage.savings
        },
        metadata: {
          vectorResultsCount: ragContext.vectorResults.length,
          memoriesCount: ragContext.memories.length,
          ragUsed: true
        }
      });

      console.log(`💾 Interaction stored for future RAG retrieval`);
    } catch (error) {
      console.error('Interaction storage error:', error);
      // Don't throw - storage failure shouldn't break the response
    }
  }

  /**
   * Find capabilities by intent
   */
  findCapabilitiesByIntent(intent: string): AgentCapability[] {
    return this.capabilityManager.findCapabilitiesByIntent(intent);
  }

  /**
   * Get capability report (for debugging/admin)
   */
  getCapabilityReport(): string {
    return this.capabilityManager.generateCapabilityReport();
  }

  /**
   * Get specific capability
   */
  getCapability(capabilityId: string): AgentCapability | undefined {
    return this.capabilityManager.getCapability(capabilityId);
  }

  abstract execute(action: string, params: Record<string, unknown>): Promise<AgentResponse>;
}